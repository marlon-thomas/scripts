#!/bin/bash

# ION Daemon database migration 
# author: Marlon Thomas

working_dir()
{
# work_dir proc taken from http://stackoverflow.com/questions/59895/getting-the-source-directory-of-a-bash-script-from-within
# gets working directory of script regarless of where it is run from. Will work even if final directory in path is a symlink  
 SOURCE="${BASH_SOURCE[0]}"
 while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
   returnv="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
   SOURCE="$(readlink "$SOURCE")"
   [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
 done
 returnv="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
 echo $returnv
}

WRK_DIR=$(working_dir)

source "$WRK_DIR/config/dependencies.config"

loadscript_suffix=load
snap_dir=snapshot
verbose=true
debug=true
logfilename=run.log
cmdfilext="ionshellcmd"
outfileext="output"
output_field_separator=";;" # field delimiter for output files - must not occur in any field values

# SYS tables to be migrated
SYS_TABLES=("SYS_C_COMP" "SYS_C_COMPDAEMON" "SYS_C_CONNECTION" "SYS_C_SCHEDULETEMPLATE" "SYS_C_VAR" "SYS_C_USERS")
PROC_NAME=("select_all" "select_all" "select_all" "select_all" "select_all" "select_all")
#PROC_NAME=("select_all" "select_all" "select_all" "select_all" "select_all" "listvar_config_comps")
# For each entry in PROC_NAME the following procedures must be defined 
#<entry>__reader
#<entry>__writer

# SYS tables to be used in pre/post release snapshots to verify integrity of migration
snapshot_tables=("SYS_C_COMP" "SYS_C_COMPDAEMON" "SYS_C_CONNECTION" "SYS_C_SCHEDULETEMPLATE" "SYS_C_USERS" "SYS_C_VAR" "SYS_C_TIME_ZONES" "SYS_C_DAEMON" "SYS_C_USERGROUP" "SYS_C_USERPROFILE")

# specify list of fields to be exlcuded for each snapshot_table below (array name MUST match excludefields_<table name>)
excludefields_SYS_C_COMP=("UpdatedBy" "UpdId" "UpdatedInfo")
excludefields_SYS_C_COMPDAEMON=("UpdatedBy" "UpdId" "UpdatedInfo")
excludefields_SYS_C_CONNECTION=("UpdatedBy" "UpdId" "UpdatedInfo")
excludefields_SYS_C_SCHEDULETEMPLATE=("UpdatedBy" "UpdId")
excludefields_SYS_C_USERS=("UpdatedBy" "UpdId" "CreationDate" "CreationTime" "FailureCount" "LastEnableDate" "LastLoginDate" "LastLoginTime")
excludefields_SYS_C_VAR=("UpdatedBy" "UpdId")
excludefields_SYS_C_TIME_ZONES=("UpdatedBy" "UpdId")
excludefields_SYS_C_DAEMON=("UpdatedBy" "Alive" "Date" "Time" "UpdId")
excludefields_SYS_C_USERGROUP=("UpdatedBy" "UpdId")
excludefields_SYS_C_USERPROFILE=("UpdatedBy" "UpdId")

main()
# main execution procedure
{
 clear
 check_dependencies
 extract_data_from_db   # runs all __reader procedures
 preprocess_data
 backup_dm_mkvdb
 load_data_to_db  # runs all __writer procedures
 #cleanup
 diff_snapshots PRE-MIGRATION POST-MIGRATION
}



check_dependencies()
{
 ok=true 
 errmsg=""
 
 if [ ! -w "$WRK_DIR" ]; then
    ok=false
    errmsg="$errmsg* Working directory $WRK_DIR is not writable for user $USERNAME.
"
 fi

 if [ ! -w "$TMP_DIR_ROOT" ]; then
    ok=false
    errmsg="$errmsg* Temp directory $TMP_DIR_ROOT is not writable for user $USERNAME.
"
 fi

 if [ ! -d "$DM_MKVDB_DIR_ROOT/MkvDB" ]; then
    ok=false
    errmsg="$errmsg* Could not find $DM_MKVDB_DIR_ROOT/MkvDB. Check \$DM_MKVDB_DIR_ROOT/MkvDB variable.
"
 else

   if [ ! -w "$DM_MKVDB_DIR_ROOT/MkvDB" ]; then
     ok=false
     errmsg="$errmsg* $DM_MKVDB_DIR_ROOT/MkvDB is not writable for user $USERNAME.
"
   fi
 fi

 if [ ! -d "$DM_MKVDB_BACKUP_DIR_ROOT" ]; then
    ok=false
    errmsg="$errmsg* Could not find backup directory $DM_MKVDB_BACKUP_DIR_ROOT. Check \$DM_MKVDB_BACKUP_DIR_ROOT/MkvDB variable.
"
 else
   if [ ! -w "$DM_MKVDB_BACKUP_DIR_ROOT/MkvDB" ]; then
     ok=false
     errmsg="$errmsg* $DM_MKVDB_BACKUP_DIR_ROOT is not writable not writable for user $USERNAME.
"
   fi
 fi

 if [ ! -f $ION_SHELL_DIR/$ION_SHELL_BIN ]; then
    ok=false
    errmsg="$errmsg* Could not find $ION_SHELL_DIR\$ION_SHELL_BIN. Check \$ION_SHELL_DIR and \$ION_SHELL_BIN variables.
"
 fi
 
 if [ $ok == false ]; then
   whiptail --title "ION DM Database Migration - DEPENDENCY CHECK FAILED" --msgbox "Please check dependency settings in ./config/dependencies.config:\n\n$errmsg" 15 110
   exit 1
 fi

 # dependency checks passed 

 # kill ion shell if it is already running
 kill -9 $(pgrep $ION_SHELL_BIN) 2> /dev/null
  

 TMP_DIR="$TMP_DIR_ROOT/tmp"
 rm -rf $TMP_DIR 2> /dev/null
 mkdir -p "$TMP_DIR"

 # clear snapshot dir if it exists
 rm -rf $WRK_DIR/$snap_dir > /dev/null 
 mkdir -p $WRK_DIR/$snap_dir

 #delete loadscript and log file
 rm -f $WRK_DIR/$loadscript $WRK_DIR/$logfilename 2> /dev/null

 logmsg "Working directory is $WRK_DIR\n" true
}

extract_data_from_db()
{
 if ( ! whiptail \
--title "ION DM Database Migration - Extract Data From DM MKV Database" \
--yesno "Please ensure the following tasks are completed before proceeding:\n\n\
   1. Stop all platform components.\n\
   2. Daemon slaves may be left running.\n\
   3. Ensure that daemon master is running.\n\n\
Proceed with extracting data from $DM_MKVDB_DIR_ROOT/MkvDB ?" 15 80)
then
    exit 0
fi
 
 take_snapshot PRE-MIGRATION  

 logmsg "Extracting data from $DM_MKVDB_DIR_ROOT/MkvDB using $ION_SHELL_DIR/$ION_SHELL_BIN:" true
 
 get_configured_comps
 
 idx=0
 for SYS_TABLE in "${SYS_TABLES[@]}"; do
   logmsg "Reading $SYS_TABLE ... " true
   ${PROC_NAME[$idx]}__reader $SYS_TABLE
   ((idx+=1))
   logmsg "done!" false
 done

}

preprocess_data()
{

 # remove default component schedule templates
 if [ -f "$TMP_DIR/SYS_C_SCHEDULETEMPLATE.$outfileext" ]; then
   grep -v "^{Default-" "$TMP_DIR/SYS_C_SCHEDULETEMPLATE.$outfileext" > "$TMP_DIR/SYS_C_SCHEDULETEMPLATE.$outfileext.new"
   mv -f "$TMP_DIR/SYS_C_SCHEDULETEMPLATE.$outfileext.new" "$TMP_DIR/SYS_C_SCHEDULETEMPLATE.$outfileext"
 fi

 # remove admin user
 if [ -f "$TMP_DIR/SYS_C_USERS.$outfileext" ]; then
   grep -v "{Admin}" "$TMP_DIR/SYS_C_USERS.$outfileext" > "$TMP_DIR/SYS_C_USERS.$outfileext.new"
   mv -f "$TMP_DIR/SYS_C_USERS.$outfileext.new" "$TMP_DIR/SYS_C_USERS.$outfileext"
 fi

 # remove non-configured components from SYS_C_VAR
 if [ -f "$TMP_DIR/SYS_C_VAR.$outfileext" ]; then
   grep -wf "$TMP_DIR/configured_comps_filter.$outfileext" "$TMP_DIR/SYS_C_VAR.$outfileext" > "$TMP_DIR/tmpfile"
   mv -f "$TMP_DIR/tmpfile" "$TMP_DIR/SYS_C_VAR.$outfileext"
 fi
}


backup_dm_mkvdb()
{
 if ( ! whiptail \
--title "ION DM Database Migration - Backup DM MKV Database" \
--yesno "Please stop all daemon components:\n\n\
   1. Stop all daemon slaves.\n\
   2. Stop daemon master.\n\n\
Press OK to proceed with automatic backup of DM database $DM_MKVDB_DIR_ROOT/MkvDB to $DM_MKVDB_BACKUP_DIR_ROOT\n\n\
You may also manually make a backup if desired. The contents of $DM_MKVDB_DIR_ROOT/MkvDB will be removed after the backup is verified and completed." \
--yes-button "OK" --no-button "Abort" \
15 115)
 then
   exit 0
 fi

 timestamp=$(date "+%Y.%m.%d-%H.%M.%S") 
 logmsg "Backing up DM MkvDB database to $DM_MKVDB_DIR_ROOT/MkvDB-$timestamp ... " true
 mkvdb_size_precopy=$(dir_size "$DM_MKVDB_DIR_ROOT/MkvDB")

 cp -r "$DM_MKVDB_DIR_ROOT/MkvDB" "$DM_MKVDB_BACKUP_DIR_ROOT/MkvDB-$timestamp"
 mkvdb_size_postcopy=$(dir_size "$DM_MKVDB_BACKUP_DIR_ROOT/MkvDB-$timestamp")

 if [ $mkvdb_size_precopy -eq $mkvdb_size_postcopy ]; then
    logmsg "Verified\n" false
    logmsg "Creating tar file $DM_MKVDB_BACKUP_DIR_ROOT/MkvDB-$timestamp.tar\n" true
    cd "$DM_MKVDB_BACKUP_DIR_ROOT"
    tar -cvf "MkvDB-$timestamp.tar" "MkvDB-$timestamp" > "$TMP_DIR/tmpfile"
    logmsg "Removing files from $DM_MKVDB_DIR_ROOT/MkvDB\n" true
    rm -f $DM_MKVDB_DIR_ROOT/MkvDB/*

    printf "\nPlease verify that MkvDB backup is secure. Press 'C' when ready to continue: "  
    INPUT=""
    while [[ ! "$INPUT" =~ ^[Cc]$ ]]; do read -n 1 -s INPUT ; done
    echo
 else
   
   logmsg "Error" false
   logmsg "MkvDB directory size changed post-backup!" true
   if ( ! whiptail --title "ION DM Database Migration - Attention Required" --yesno "There was a problem with the automatic backup. Please ensure $DM_MKVDB_DIR_ROOT/MkvDB is backed up and its contents are removed before proceeding." \
--yes-button "Proceed With Migration" --no-button "Abort" 15 100)
   then
       logmsg "User aborting ....\n" true
       exit 1      
   fi
 fi
}

insert_admin_user()
{
 # This must be the same admin platform user that the shell is using to register to the platform 
 # this procedure will be called before re-loading of data to the target database
 # ensure this admin user is removed in the preprocess_data() procedure
 
 logmsg "Inserting admin user ..." true

 #TABLE="SYS_C_USERS"
 #VALUES="{10} {Admin} {78 48 13 A4 C6 26 } {4} {18} {0} {} {CE97FD26027DD2B9} {0} {1} {0} {} {} {} {0} {20170402} {20170309} {21540539} {20170307} {8231108} {20170307} {} {1561996_SA_DEVINT} {0} {0}"
 #read -r FIELDS < "$TMP_DIR/${TABLE}_field_list.$outfileext"
 #FIELDS="UserID UserName Password Type Passwdlen Auth AuthSource PasswdExt Disabled LoginMode DisablePasswdCheck FullName Email PersonalInfo FailureCount LastLoginDate LastPwdChangeDate LastLoginTime CreationDate CreationTime LastEnableDate LinkedPolicy UpdatedBy DirtyFlag UpdId"
 #SHELL_CMDS=("INSERT INTO {$TABLE} {$FIELDS} VALUES {$VALUES}")

 SHELL_CMDS=("adduser -u {Admin} -t {Admin} -p {Admin} -i {10}")
 execute_shell_cmds "$TMP_DIR" "insert_admin_user" 

 logmsg " done." false
}

load_data_to_db()
{

if ( ! whiptail \
--title "ION DM Database Migration - Load Target DM Database" \
--yesno "Please ensure the following tasks are completed before proceeding:\n\n\
   1. Ensure backup of MkvDB database in $DM_MKVDB_DIR_ROOT is secure (or alternatively make your own backup).\n\
   2. Apply mkv.init configration changes to daemon master to use target database.\n\
   3. Re-start daemon master.\n\
   4. Confirm deamon master has made successful connection to target database.\n\
   5. Ensure that no processes other than daemon slaves are registered to the platform.\n\
   6. In the Sysadmin create admin user that the daemon shell will login with.\n\n\
Proceed with loading of target database?" \
--yes-button "Proceed" --no-button "Abort" \
15 120)
then
   logmsg "User aborting ....\n" true
   exit 0
fi

 #insert_admin_user

 idx=0
 for SYS_TABLE in "${SYS_TABLES[@]}"; do
   logmsg "Loading $SYS_TABLE data to target database ... " true
    ${PROC_NAME[$idx]}__writer $SYS_TABLE
   ((idx+=1))  
   logmsg "done!\n" false
 done

 take_snapshot POST-MIGRATION
}

cleanup()
{
 #  tmp directory
 rm -f $TMP_DIR/* 2> /dev/null 
}

diff_snapshots()
{
 FIRST_SS="$WRK_DIR/$snap_dir/$1"
 SECOND_SS="$WRK_DIR/$snap_dir/$2"
 reportfile="$1_$2_comparison_report.log"
 divider="============================================================================================"
 
 printf "%s\nTable-by-table comparison:\n%s\n" "$divider" "$divider" > "$WRK_DIR/$reportfile"
 for SSTABLE in "${snapshot_tables[@]}"; do
   FILE=${SSTABLE}_snapshot.$outfileext
   printf "\n%s\n%s FIELDS: %s" "$FILE" "$SSTABLE" "$(head -n 2 $FIRST_SS/$FILE)" >> $WRK_DIR/$reportfile
   diff -r -N --unidirectional-new-file $FIRST_SS/$FILE $SECOND_SS/$FILE >> "$WRK_DIR/$reportfile"
 done
 # diff snapshot directories
 
 printf "\n%s\nDirectory comparison:\n%s\n" "$divider" "$divider" >> "$WRK_DIR/$reportfile"
 diff -r -N --unidirectional-new-file $FIRST_SS $SECOND_SS >> "$WRK_DIR/$reportfile"


 whiptail --title "ION DM Database Migration - COMPLETED" --msgbox "Press OK view diff report between $1 and $2 snapshots.\n" 15 60
 exec less "$WRK_DIR/$reportfile" #so script can exit
}

take_snapshot()
{

 TAG=$1
 logmsg "$(printf "Taking snapshot of %s tagged as: %s " "$DM_MKVDB_DIR_ROOT/MkvDB" "$TAG")" true
 tag_dir="$WRK_DIR/$snap_dir/$TAG"
 mkdir "$tag_dir"
 
 for SSTABLE in "${snapshot_tables[@]}"; do

   #get field list
   SHELL_CMDS=("SELECT {\*} FROM {$SSTABLE} WHERE [expr False]")
   execute_shell_cmds "$TMP_DIR" "${SSTABLE}_SS_field_list" "sed -e '/^\s*$/d;1,7d' | head -n 1"

   EXCL_FIELDS=excludefields_$SSTABLE[@] 
   for excl_field in "${!EXCL_FIELDS}"; do
      # remove from list
      cat "$TMP_DIR/${SSTABLE}_SS_field_list.$outfileext" | sed -e "s/$excl_field//g;s/^ //g;s/ $//g;s/  / /g" > "$TMP_DIR/tmpfile"
      mv -f "$TMP_DIR/tmpfile" "$TMP_DIR/${SSTABLE}_SS_field_list.$outfileext"
   done
   
   #query and snapshot table using reduced field list
   read -r FIELDS < "$TMP_DIR/${SSTABLE}_SS_field_list.$outfileext"
   
   SHELL_CMDS=("SELECT {$FIELDS} FROM {$SSTABLE} WHERE [expr True]")
   execute_shell_cmds "$tag_dir" "${SSTABLE}_snapshot" "sed -e '/^\s*$/d;1,7d'"

   logmsg "." false
 done
 
 #reduce SYS_C_VAR snapshot if it exists, to contain only settings for configured components
 if [ -f "$tag_dir/SYS_C_VAR.snapshot.$outfileext" ]; then
   grep -wf "$TMP_DIR/configured_comps_filter.$outfileext" "$tag_dir/SYS_C_VAR.snapshot.$outfileext" > "$TMP_DIR/tmpfile"
   mv -f "$TMP_DIR/tmpfile" "$tag_dir/SYS_C_VAR.snapshot.$outfileext"
 fi  
 echo " done!"
}


execute_shell_cmds()
{

 # SHELL_CMDS is an array containing ION shell commands - must be set by caller (passing arrays not worthwhile in bash)
 # LABEL is the tag that will be given to the output file containing the ION shell output 
 # OUTPUT_DIR is the location that the output file will be written to.
 # FILTER_CMD_STRING is an eval filter string that the output will be passed to before being written to disk
 # calling fn needs to set SHELL_CMDS
 
 OUTPUT_DIR=$1
 LABEL=$2
 FILTER_CMD_STRING=${3:-cat} # if no filter command string is provided jut pass the stream on unmodified

 # build_ion_shell_cmd_file 
 
 SHELL_CMD_FILE="$OUTPUT_DIR/$LABEL.$cmdfilext"

 printf "connect -init;\n" > "$SHELL_CMD_FILE"
 for shell_cmd in "${SHELL_CMDS[@]}"; do
     if [ $debug == true ]; then logmsg "\nDEBUG: shell_cmd = $shell_cmd" true ; fi
     printf "%s\n" "$shell_cmd"  >> "$SHELL_CMD_FILE"
 done
 printf "exit\n\n" >> "$SHELL_CMD_FILE" 

  if [ $debug == true ]; then logmsg "DEBUG: filter = $FILTER_CMD_STRING" true ; fi

 #run_ion_shell 
 
 cd "$ION_SHELL_DIR"
 # execute!

 if [ $debug == true ]; then logmsg "DEBUG: executing $SHELL_CMD_FILE ... " true ; fi
 "./$ION_SHELL_BIN" 2> /dev/null < "$SHELL_CMD_FILE" | eval "$FILTER_CMD_STRING" 1> "$OUTPUT_DIR/$LABEL.$outfileext"
 

 if grep "Platform connection failed" "$OUTPUT_DIR/$LABEL.$outfileext" ; then
    logmsg "*********************************************************************************************" true
    logmsg "ERROR: Daemon shell is not registered to platform. Restore DM database and restart procedure." true
    exit 1
 else
    if [ $debug == true ]; then logmsg "DEBUG: completed" true ; fi
 fi

 if grep "command failed: Timeout" "$OUTPUT_DIR/$LABEL.$outfileext" ; then
   logmsg "WARNING: Timeout occurred for one or more commands in $OUTPUT_DIR/$LABEL.$outfileext" true
 fi

 cd "$WRK_DIR"
 
}

get_configured_comps()
{
 # create a filter file for configured components where each row is is of the form ^{<comp name>}
 # can be used to filter files where each row starts with {<comp name>} 
 logmsg "Reading list of configured components ... " true

 SHELL_CMDS=("listcomp -t config")
 execute_shell_cmds "$TMP_DIR" "configured_comps_filter" "sed -e '/^\s*$/d;1,2d' | head -n -5 | awk '{printf \"^{%s}\n\",\$1}'"

 CONFIGURED_COMPS=()
 while IFS= read -r row; do
  clean_row=$(echo "$row" | sed -e 's/[{}\^]//g')
  CONFIGURED_COMPS+=($clean_row)
 done < "$TMP_DIR/configured_comps_filter.$outfileext"

}

#************************************************#
#***           readers and writers            ***#
#************************************************#

#======================================================================================#

select_all__reader()
{
 TABLE=$1

 SHELL_CMDS=("SELECT \* FROM {$TABLE} WHERE [expr True]")
 execute_shell_cmds "$TMP_DIR" "$TABLE" "sed -e '/^\s*$/d;1,7d'"

 head -n 1 "$TMP_DIR/$TABLE.$outfileext" > "$TMP_DIR/$TABLE.fields" # strip out header
 sed -e '1,2d' "$TMP_DIR/$TABLE.$outfileext" > "$TMP_DIR/tmpfile"
 mv -f "$TMP_DIR/tmpfile" "$TMP_DIR/$TABLE.$outfileext"
}

select_all__writer()
{
 TABLE=$1 #add to all writer procs

 read -r FIELDS < "$TMP_DIR/$TABLE.fields"
 SHELL_CMDS=()

 while read -r LINE; do
   # escape special characters in LINE 
   VALUES=$(escape_chars "$LINE")
   #VALUES=$LINE
   ## WARNING: Do not escape any chars used in output_field_separator
   CMD="INSERT INTO {$TABLE} {$FIELDS} VALUES {$VALUES}"
   SHELL_CMDS+=("$CMD")
   
 done < "$TMP_DIR/$TABLE.$outfileext"

 execute_shell_cmds "$TMP_DIR" "$TABLE.select_all_writer" 
}

#======================================================================================#


listvar_config_comps__reader()
{
 SHELL_CMDS=()
 splitprefix=complistvar_splitfile
 
 for comp in ${CONFIGURED_COMPS[@]}; do
    CMD="listvar -n {$comp} -t config"
    SHELL_CMDS+=("$CMD")
 done
 
 execute_shell_cmds "$TMP_DIR" "ALL_CONFIG_COMPS.listvar" "sed -e '/^\s*$/d' | head -n -5"
 
 csplit -s -k "$TMP_DIR/ALL_CONFIG_COMPS.listvar.$outfileext" "/^$(head $TMP_DIR/ALL_CONFIG_COMPS.listvar.$outfileext -n 1 | awk '{for (i=1; i<=NF; i++) printf "%s *", $i}')/" {*} --prefix "$TMP_DIR/$splitprefix"
 
 # convert fixed width output files to character delimited
 i=1
 echo $i > "$TMP_DIR/ctr"
 for comp in ${CONFIGURED_COMPS[@]}; do
    splitsuffix=$( printf "%02d" "$i" )     
    convert_fixedwidth_data_to_csv "$TMP_DIR/${splitprefix}${splitsuffix}" "$TMP_DIR/$comp.listvar.delimited.$outfileext" 
    #i=$[$i+1]
    i=$[ $(cat "$TMP_DIR/ctr") + 1 ]
    echo $i > "$TMP_DIR/ctr"   # unusual method used to increment i because of subshell opened by convert_fixedwidth_data_to_csv
 done
 rm $TMP_DIR/${splitprefix}*
}


listvar_config_comps__writer()
{
 TABLE=$1 #add to all writer procs

 SHELL_CMDS=()
 for comp in ${CONFIGURED_COMPS[@]}; do
    while read -r LINE; do
    # escape special characters in LINE 
        VALUES=$(escape_chars "$LINE") 
        ## WARNING: Do not escape any chars used in output_field_separator
        CMD=$( echo "$VALUES" | awk -v compname="$comp" -F"$output_field_separator" '{printf "addvar -n {%s} -s {%s} -v {%s} -e {%s} -c {%s}\n",compname,$1,$2,1-$3,$4}' )
        # addvar -n <comp name> {-s <var name> -v <var value> [-e 0|1] [-c <comment>] | -f <settings file> [-i] [-j] }
        SHELL_CMDS+=("$CMD")
    done < "$TMP_DIR/$comp.listvar.delimited.$outfileext"    
 done
 
 execute_shell_cmds "$TMP_DIR" "$TABLE.listvar_config_comps__writer"
 
}

#======================================================================================#
convert_fixedwidth_data_to_csv()
{
 # converts fixed width input to character delimited values
 # uses the string index values of the file header to determine the column widths
 # the delimiter is set using the OFS output field separator in the delimit.awk script
 
 INFILE=$1
 OUTFILE=$2
 HEADER=$(head -n 1 $INFILE | expand ) # expand in case of tabs in file
 FIELDS=$( echo $HEADER | awk {' for (i=1;i<=NF;i++) print $i '})

 idxvalues=()
 i=0
 for f in ${FIELDS[@]}; do
   idx=$(strindex "$HEADER" "$f")
   idxvalues[$i]=$idx
   ((i++))
 done
 # add length of longest line in file to idxvalues
 idxvalues[$i]=$(( $( wc -L "$INFILE" | awk '{print $1}' ) + 1 ))
 
 colwidths=()
 j=0
 for (( i=0; i<${#idxvalues[@]}; i++ )); do
   if [ $i -gt 0 ]; then
      colwidths[$j]=$(( idxvalues[$i] - idxvalues[$i-1] ))
      ((j++))
   fi
 done
 
 # extra sed to remove first two lines from file 
 expand "$INFILE" | sed -e '1,2d' | awk -v output_field_separator="$output_field_separator" -v colw="$( echo ${colwidths[@]})" -f "$WRK_DIR/awkscripts/delimit.awk" > "$OUTFILE" 

}

dir_size() 
{
 echo $(du -bs $1 | awk '{print $1}')
}

strindex() {
  PARENT=$1
  SUBSTRING=$2
  echo $(awk -v a="$PARENT" -v b="$SUBSTRING" 'BEGIN{print index(a,b)}')
}

escape_chars()
{
 # escapes characters in INPUT_STR that need to be written to the ION shell DB
 INPUT_STR=$1
 # escape the following characters between [ and ]
 #echo $INPUT_STR | sed -e 's/["]/\\&/g;1{$s/^$/""/}; 1!s/^/"/; $!s/$/"/'
 echo $INPUT_STR | cat
}


logmsg()
{

 MSG=$1
 TS=${2:-false}  # true if MSG is to be timestamped, false otherwise
 msgtimestamp=$(date "+%Y.%m.%d-%H.%M.%S")  
 logstr="$msgtimestamp | $MSG"

 if [ $TS == true ]; then
   printf "\n$logstr"
   printf "\n$logstr" >> "$WRK_DIR/$logfilename"
 else
   printf "$MSG"
   printf "$MSG" >> "$WRK_DIR/$logfilename"
 fi
}

main
