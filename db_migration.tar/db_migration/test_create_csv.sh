#!/bin/bash

main()
{
 #convert_fixedwidth_data_to_csv "/dev/shm/output" "/dev/shm/out.csv"
 
 escape_chars "{TRADE_MANAGER} {ROUTER_CREDIT_M} {3} {0} {1558931_SA_DEVINT} {0} {0}"
}

convert_fixedwidth_data_to_csv()
{
 # converts fixed width input to character separated values
 # default character is comma (,) and can be set using the output field separator in the awk scripts
 
 INFILE=$1
 OUTFILE=$2

 HEADER=$(head -n 1 $INFILE | expand ) # expand in case of tabs in file
 FIELDS=$( echo $HEADER | awk {' for (i=1;i<=NF;i++) print $i '})

 idxvalues=()
 i=0
 for f in ${FIELDS[@]}; do
   idx=$(strindex "$HEADER" "$f")
   idxvalues[$i]=$idx
   ((i++))
 done
 # add length of longest line in file to idxvalues
 idxvalues[$i]=$(( $( wc -L $INFILE | awk '{print $1}' ) + 1 ))
 
 colwidths=()
 j=0
 for (( i=0; i<${#idxvalues[@]}; i++ )); do
   if [ $i -gt 0 ]; then
      colwidths[$j]=$(( idxvalues[$i] - idxvalues[$i-1] ))
      ((j++))
   fi
 done
   
 expand "$INFILE" | sed -e '2,1d' | awk -v colw="$( echo ${colwidths[@]})" -f "awkscripts/delimit.awk" > "$OUTFILE" 

}

strindex() {
  PARENT=$1
  SUBSTRING=$2
  echo $(awk -v a="$PARENT" -v b="$SUBSTRING" 'BEGIN{print index(a,b)}')
}

escape_chars()
{
 # escapes characters in INPUT_STR that need to be written to the ION shell DB
 INPUT_STR=$1
 # escape the following characters between [ and ]
 echo $INPUT_STR | sed -e 's/[!@#$%^&*()"|\/:?<>=+]/\\&/g;1{$s/^$/""/}; 1!s/^/"/; $!s/$/"/'
}
main

